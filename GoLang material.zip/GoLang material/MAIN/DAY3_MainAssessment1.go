package main
import	"fmt"
func main() {
	var city,region,continent string
	fmt.Println("Enter the City name:")
	fmt.Scanln(&city)
	region,continent= fun2(city)
	fmt.Printf("%s : Region - %q, Continent - %q",city,region,continent)
}

func fun2(city string) (string,string) {
	var re,con string
	switch city {
case "Chennai": 
re= "Tamil Nadu"
con="Asia"
case "CHN": 
re= "Tamil Nadu"
con="Asia"
case "Kolkata": 
re= "West Bengal"
con="Asia"
case "KOL": 
re= "West Bengal"
con="Asia"

}
return re,con
}