package main
import "fmt"
type Account struct {
    accountnumber int
    balanceamount int
    
}

func main() {
    var cus1 Account
    var acc int
    var balance int
    var ch int
    fmt.Println("Enter the account number")
    fmt.Scanln(&acc)
    fmt.Println("Enter the deposit")
    fmt.Scanln(&balance)
    
    cus1.accountnumber=acc
    cus1.balanceamount=balance
    
    fmt.Println("Menu\n1.Deposit\n2.Withdrawal")
    fmt.Scanln(&ch)
    if(ch==1) {
       deposit(cus1)
   }else if(ch==2){
       withdrawal(cus1)
   }
   }
    func deposit(cus1 Account) {
        var newamount int
        fmt.Println("Id= ",cus1.accountnumber)
        fmt.Println("Enter the amount to be deposited")
        fmt.Scanln(&newamount)
       
        cus1.balanceamount=cus1.balanceamount +newamount

        fmt.Println("New Balance",cus1.balanceamount)
       
        

    }
    
    func withdrawal(cus1 Account) {
        var newamount int
        fmt.Println("Id= ",cus1.accountnumber)
        fmt.Println("Enter the amount to be withdrawed")
        fmt.Scanln(&newamount)
       if(cus1.balanceamount >newamount) {

        cus1.balanceamount=cus1.balanceamount -newamount
        fmt.Println("New Balance ",cus1.balanceamount)

       }else {
        fmt.Println("Insufficient balance")

       }
     //  fmt.Println("New Balance",cus1.balanceamount)
    }