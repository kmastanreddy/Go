package main
import "fmt"
func main() {
	fmt.Println("Enter the 1st number")
	var a float64
	fmt.Scanln(&a)
	fmt.Println("Enter the 2nd number")
	var b float64
	fmt.Scanln(&b)
	fmt.Println("Enter the function to be performed")
	var c string
	fmt.Scanln(&c)
var d float64
	switch(c) {
	case "+":  
	d = a+b
	fmt.Print("the value is ",d)  
	case "-":  
	d = a-b
	fmt.Print("the value is ",d)    
	case "*":  
	d = a*b
	fmt.Print("the value is ",d)    
	case "/":  
	d = a/b
	fmt.Print("the value is ",d)   
  default:  
	fmt.Print(" Please type the correct input ") 
	}
}