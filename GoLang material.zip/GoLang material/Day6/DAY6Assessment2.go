package main  
import (  
   "sync"  
//  "time"  
 //  "math/rand"  
   "fmt"  
)  
var wait sync.WaitGroup  
 var balance int=10000  
var mutex sync.Mutex  
func  banking(s string,amount int)  {  
 //  for i :=0;i<10;i++ {  
      mutex.Lock()  
      if(s=="deposit") {
     balance=balance+amount  
       } else if (s=="withdrawal") {
        balance=balance-amount  
          } // time.Sleep(100*time.Millisecond)  
      //count = x;  
      fmt.Println("Balance: ",balance)  
      mutex.Unlock() 
      
        
 //  }  
   wait.Done()  
     
}  
func main(){  
    //var q[] string={"What is your name","What is your age",""}
    wait.Add(2)  
    for{
    
    fmt.Println("1.deposit\n2.Withdrawal\n3.Exit\nSelect any option")
    var choice int
    fmt.Scanln(&choice)
    
        if(choice==1) {
            fmt.Println("Enter the AMOUNT")
            var x int
            fmt.Scanln(&x)
        go banking("deposit",x)  
        } else if(choice==2) {
            fmt.Println("Enter the AMOUNT")
            var y int
            fmt.Scanln(&y)
        go banking("withdrawal",y)
        }else if(choice==3) {

            break;
        
  
    }
  
}

   wait.Wait()  
  // fmt.Println("last count value " ,count)  
}
