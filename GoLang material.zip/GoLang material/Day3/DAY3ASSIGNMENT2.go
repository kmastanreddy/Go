package main
import ( 
    "fmt"
   
)
func main() {
    var children[10] string
    var count int
    fmt.Println("Enter the names of 10 children")
    for i:=0;i<10;i++ {
        fmt.Scanln(&children[i])
    }
    for i:=0;i<10;i++ {
        for _, value := range children[i] {
            switch value {
            case 'a', 'e', 'i', 'o', 'u', 'A', 'E', 'I', 'O', 'U':
                count++
            }
        }

        
    }
    rgift:=50-count
    fmt.Println("Remaining gifts =",rgift)

}
