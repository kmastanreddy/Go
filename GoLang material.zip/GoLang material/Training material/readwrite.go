package main
import (
   "log"
   "os"
)
func main() {
   file,err :=os.OpenFile("test.txt",os.O_WRONLY,0666)
  if err!=nil {
     if os.IsPermission(err) {
     log.Println("error: write permission denied")
     }
   
  }
    log.Println("ready to read")
    file.Close()

file1,err1 :=os.OpenFile("test.txt",os.O_RDONLY,0666)
  if err1!=nil {
     if os.IsPermission(err1) {
     log.Println("error: REad permission denied")
     }
   
  }
    log.Println("ready to write")
    file1.Close()
   

   }

