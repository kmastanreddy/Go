package main
import ( 
        "fmt"
        "time"
)
func main() {
//	t:=time.Now()
//  	fmt.Println(t)
//	t1:=time.Now().UTC() //Coordinated UniversalTime
//	fmt.Println(t1)
	//	t2:=time.Now().Unix() //timestamp
  	//	fmt.Println(t2)
  	//	fmt.Println(t.Format("206-01-02 15:04:05"))
  	//	fmt.Println(t.Format(time.ANSIC))

        d:=time.Now().Sub(then)
        	fmt.Println(int(d.Hours()/24))

//        diff:=t.Sub(then)
//     fmt.Println(diff)
//      duration:=time.Since(then)
//      diff:=time.Now().Sub(then)
//     fmt.Println(diff.Hours())

   t1:=time.Now()
   t2:=t1.Add(time.Hour*24)
 fmt.Println(t1)
fmt.Println(t2)

}







 
 







/*
 var map1 map[int]string =map[int]string {
 1:"Oracle"
 2:"Mysql"
 3:"Couchdb"
 4:"MongoDB",
}
 for k,v := range map1 {
  fmt.Println(k,v)
}
  


*/  