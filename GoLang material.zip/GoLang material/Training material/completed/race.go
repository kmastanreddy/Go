package main
import  (
   "fmt"
   "time"
   "sync" 
   "sync/atomic"
)
var wait sync.WaitGroup
var count int64
//var m sync.Mutex
func increment (s string) {
  for i:=0;i<10;i++ {
  //      m.Lock() // count get locked
  //x:=count
   //     x++
     atomic.AddInt64(&count,1)
      time.Sleep(100*time.Millisecond)
    //  count =x
   //    m.Unlock() //count get unlocked
      fmt.Println(s,i,"Count:",count)
  }
   wait.Done()
}
func main() {
    wait.Add(2)
    go increment("foo:")
    go increment("bar:")
    wait.Wait()
    fmt.Println("last  count value:",count)
    fmt.Println("Main function")
 }

