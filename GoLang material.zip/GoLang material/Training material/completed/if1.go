package main
import "fmt"
func main() {
  var x int
  fmt.Println("enter any number")
  fmt.Scanln(&x)
  if x<10  { //simple if
    fmt.Println("below 10")
 } else if (x>=10 && x<20)
{
    fmt.Println("10 to 20 range") 
  } else if (x>=20 && x<30) {
    fmt.Println("20 to 30 range") 
  } else {
    fmt.Println("out of range") 
}
}