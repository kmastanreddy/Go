package main

func main() {
  _,err :=  10/0  
  if err!= nil {
    panic(err)
 }

}

