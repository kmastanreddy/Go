package main
import "fmt"
type cust struct {
 id int
 name string
}

func main() {
  c:=make(map[string]cust)
 fmt.Println("entre key and values")
  for k,v := range c {
    fmt.Scanln(&k,&v)
}

  c["java"]=cust{1,"raj"}
  c["golang"]=cust{2,"kiran"}
  c["db"]=cust{3,"raj"}
  c["etl"]=cust{4,"kiran"}
 fmt.Println(c["java"],c["golang"])//printing using keys
 fmt.Println(c) //printing whole map object
 for k,v := range c {  //iterating map element by elemnt
   fmt.Println(k,v)   //k ,v.id,v.name

 var c1=map[string]cust{"java7" : cust{10,"Spring",},
                        "java8"  :cust{20,"Lambda",},}
  
 fmt.Println(c1);
  for k,v := range c1 {
    fmt.Println(k,v)
}
}







 
 







/*
 var map1 map[int]string =map[int]string {
 1:"Oracle"
 2:"Mysql"
 3:"Couchdb"
 4:"MongoDB",
}
 for k,v := range map1 {
  fmt.Println(k,v)
}
  


*/  