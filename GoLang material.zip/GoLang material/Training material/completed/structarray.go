package main
import  "fmt"
type cust struct {
 id int
 name string
}


func main() {
b:=make([]int,5)
   c:=[]cust {}
 for i:=1;i<6;i++ {
   x:=cust{id:1,name:"cts"}
   c=append(c,x)
}
   fmt.Println(c,len(c),cap(c))
   fmt.Println(len(b),cap(b))
 }

 