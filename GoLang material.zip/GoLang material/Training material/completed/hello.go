package main
import "fmt"
var city string="Chennai"
func main() {
  var a int=20
  var b float64=456.23
  var name string="ramesh"
  var result bool =true
 fmt.Println(a,b,name,result)
 fmt.Printf("%v %v %v",a,b,name)
 fmt.Printf("%T %T %T",a,b,name)
 fmt.Printf("%q",name)
 fmt.Printf("%t",result)
 fmt.Println(city)
}