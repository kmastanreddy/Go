package main
import ( 
      "fmt"
      "strconv"
)
func main() {
     var i int =10
     var j  float64=23.45
     var s1 string ="123"
     var s2 string="4567.234"
     j1:=float64(i)
    fmt.Println(i,j)
    fmt.Println(int(j))
    fmt.Println(float64(i),j1)
    fmt.Println(strconv.ParseInt(s1,0,64))
    fmt.Println(strconv.ParseFloat(s2,64))
 }

