
package main
import "fmt"
func main() {
  a:=make(map[string]int)
  a["i1"]=10
  a["i2"]=20
  fmt.Println(" Map :",a)
  
  i1value:=a["i1"]
  fmt.Println(" i1value :",i1value)
  
  delete(a,"i2")
  fmt.Println(" Map :",a)
  
  b:=map[int]string{1:"java",2:"golang"}
  fmt.Println(" Map :",b)
}
  