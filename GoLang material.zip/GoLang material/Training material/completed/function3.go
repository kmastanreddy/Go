package main
import "fmt"
func fun(a int,b int) (int,int) { //return type of function
  return a+b,a-b    //function body
}
func main() {
  x,y:=fun(10,20) //multiple return types can be stored
  fmt.Println(x,y) //return value from function
  fmt.Println(fun(50,40))
}