/*

var questions[] string {"1.What is a routine?",
		       "2.How to decaare a map",
                       "3.How to initilize array" }

load the question one by one and wait for 
2 minutes to input user answer  nd store all 
  user given answers into answer array.

*/

package main
import "fmt"
import "time"
func numbers() {
  for i:=1;i<=5;i++ {
   time.Sleep(100 * time.Millisecond)
   fmt.Printf("%d\n",i)
   }
}
func alphabets() {
  for i:='a' ;i<='e';i++ {
   time.Sleep(100 * time.Millisecond)
   fmt.Printf("%c\n",i)
   }
}
func main() {
   go numbers()
   go alphabets()
   time.Sleep(1000 * time.Millisecond)
   fmt.Println("Main stopped")  
}
