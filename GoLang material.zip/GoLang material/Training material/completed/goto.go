package main
import "fmt"
func main() {
  var age int
loop:
    fmt.Printf("Not eleigible for vote ")
    fmt.Printf("enter age ")
    fmt.Scanln(&age)
     if(age <=17) {
       goto loop
     } else {
 fmt.Println("you can vote ",age)
 fmt.Printf("you can vote %d ",age)

 }
}