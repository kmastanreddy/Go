package main
import "fmt"
func main() {
   c:=make(map[int] string)
  for i:=0;i<3;i++ {
    fmt.Scanln(c[i])
    }
    fmt.Println(c)  
}







 
 







/*
 var map1 map[int]string =map[int]string {
 1:"Oracle"
 2:"Mysql"
 3:"Couchdb"
 4:"MongoDB",
}
 for k,v := range map1 {
  fmt.Println(k,v)
}
  


*/  