package main
import "fmt"
func main() {
 var x int=10
 var ptr=&x
 fmt.Println("go- Pointers")
 fmt.Println(x)
 fmt.Println(ptr)//address of x
 fmt.Println(*ptr) //value store in pointer
 *ptr=20  //
 fmt.Println(x) //new value of x
 


}