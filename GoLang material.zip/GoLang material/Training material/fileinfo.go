package main
import (
   "log"
   "os"
)

func main() {
    fileInfo,err:=os.Stat("test.txt")
    if err !=nil {
         log.Fatal("File does not exist")
    }
  
   log.Println("File name:",fileInfo.Name())
   log.Println("Size:",fileInfo.Size())
   log.Println("Permission:",fileInfo.Mode())
   log.Println("lastmodified:",fileInfo.ModTime())
   log.Println("IdDirectory:",fileInfo.IsDir())
   log.Println("Systeminfo:",fileInfo.Sys())


}

