package main
import (
   "fmt"
 )
type polygon interface {
   area() int
   peri() int
}
type sq struct{
    side int
}
type rect struct{
    l int
    b int
}
func(s sq) area() int {
     return s.side*s.side
}
func(s sq) peri() int {
     return 4*s.side
}
func(r rect) area() int {
     return r.l*r.b
}
func(r rect) peri() int {
     return 2*(r.l+r.b)
}
func calcareaperi(p polygon) {
   fmt.Println(p)
   fmt.Println(p.area())
   fmt.Println(p.peri())
}
func main() {
  s:=sq{side:5}
  r:=rect{l:5,b:6}
  calcareaperi(s)
  calcareaperi(r) 
  
}
