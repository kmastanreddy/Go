package main
import (
   "log"
   "os"
)
var (
    fileinfo *os.FileInfo
    err  error
)
func main() {
    fileinfo,err:=os.Stat("test.txt")
    if err !=nil {
      if os.IsNotExist(err) {
      log.Fatal("File does not exist")
    }
   }
   log.Println("File exist")
   log.Println(fileinfo)
}

