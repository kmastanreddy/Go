package main

import (
   "fmt"
)
type notifier interface {
   notify()
}
type user struct{
    name string
    email string
}
func(u user) notify(){
    fmt.Printf("sending mail to %s %s\n",u.name,u.email)
}
func send(n notifier) {
  n.notify()
}
func main() {
 u:=user{"Ra","raj@gmail.com"}
  send(u)
}
