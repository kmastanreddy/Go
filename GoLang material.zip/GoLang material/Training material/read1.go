package main
import (
   "fmt"
   "io/ioutil"
   "strings"
)
func main() {
   fs,err :=ioutil.ReadFile("test.txt")
  if err!=nil {
     fmt.Println("error is :",err)
    
  }
     str:=string(fs) 
    fmt.Println(str)
        fmt.Println(strings.ToUpper(str))

}

