package main
import "fmt"


type Loan interface {			<<//INTERFACE declaration
    getEmi() float64
}


type HousingLoan struct {		<<//STRUCT declaration
    amount float64
}
type PersonalLoan struct {
    amount float64
}


func(hl HousingLoan) getEmi(amt float64) float64 {		<<//FUNCTION declaration
    return 0.09 *amt  
}
func(pl PersonalLoan) getEmi(amt float64) float64 {
    return 0.12 *amt  
}


func main() {							<<//Main Function declaration
    hll:= HousingLoan{}
    pll:= PersonalLoan{}
    fmt.Println("Enter the principle amount for housing loan")
    fmt.Scanln(&hll.amount)
    h:=hll.getEmi(hll.amount)
    fmt.Printf("%0.2f ",h)
    fmt.Println("Enter the principle amount for personal loan")
    fmt.Scanln(&pll.amount)
    p:=pll.getEmi(pll.amount)
    fmt.Printf("%0.2f ",p)
}
